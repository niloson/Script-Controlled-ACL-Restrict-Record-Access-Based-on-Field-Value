# Script-Controlled ACL – Restrict Record Access Based on Field Value

## Project Overview
This project demonstrates how a script-controlled Access Control List (ACL) can restrict record access according to the value stored in a field.

The example uses a ServiceNow-style ACL approach. The ACL evaluates a record field and the current user's role before allowing access.

### Example Rule
- Records with `u_access_level = "public"` can be read by authenticated users.
- Records with `u_access_level = "restricted"` require the `x_company.restricted_user` role.
- Records with `u_access_level = "confidential"` require the `x_company.admin` role.

> Adapt table names, field names, roles, and conditions to your ServiceNow application.

## Repository Structure
1. Brainstorming & Ideation
2. Requirement Analysis
3. Project Design Phase
4. Project Planning Phase
5. Project Development Phase
6. Project Testing
7. Project Documentation
8. Project Demonstration

## Technologies
- ServiceNow ACL
- JavaScript
- ServiceNow user/role model
- GitHub for project documentation

## Objective
To implement field-based record access control using a scripted ACL and verify that users receive access only when the configured field value and role requirements are satisfied.
