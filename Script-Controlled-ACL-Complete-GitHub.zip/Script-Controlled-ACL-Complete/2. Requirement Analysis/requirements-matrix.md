# Requirements Matrix

| ID | Requirement | Priority | Verification |
|---|---|---|---|
| FR1 | Access field exists | High | Table configuration |
| FR2 | Public records are readable | High | ACL test |
| FR3 | Restricted records require restricted role | High | ACL test |
| FR4 | Confidential records require admin role | High | ACL test |
| FR5 | Unknown values are denied | High | Negative test |
| FR6 | Unauthorized access is blocked server-side | High | Security test |
| NFR1 | Script is readable | Medium | Code review |
| NFR2 | Decision is deterministic | High | Repeated tests |
