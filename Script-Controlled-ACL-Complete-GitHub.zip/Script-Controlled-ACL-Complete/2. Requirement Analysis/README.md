# 2. Requirement Analysis

## Functional Requirements

### FR1 – Record Field
The target table must contain a field named `u_access_level`.

### FR2 – Public Records
If the field value is `public`, authenticated users can read the record.

### FR3 – Restricted Records
If the field value is `restricted`, the user must have the `x_company.restricted_user` role.

### FR4 – Confidential Records
If the field value is `confidential`, the user must have the `x_company.admin` role.

### FR5 – Unknown Values
Unknown or empty values must not automatically grant privileged access.

### FR6 – Testing
The implementation must be tested with users having different roles and records having different field values.

## Non-Functional Requirements
- Server-side enforcement
- Clear and maintainable script
- Minimal processing overhead
- Predictable deny behavior
- Easy configuration and maintenance

## Assumptions
- The example is implemented using a ServiceNow-style ACL.
- The custom field `u_access_level` exists on the target table.
- Roles are created before testing.
