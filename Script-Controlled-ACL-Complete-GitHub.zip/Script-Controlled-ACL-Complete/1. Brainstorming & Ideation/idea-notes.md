# Idea Notes

## Actors
- Normal authenticated user
- Restricted-access user
- Administrator
- ACL/security administrator

## Inputs
- Record field: `u_access_level`
- Current user roles

## Output
- `true` → access is allowed
- `false` → access is denied

## Security Principle
Client-side hiding is not sufficient for protecting records. The server-side ACL must make the final access decision.
