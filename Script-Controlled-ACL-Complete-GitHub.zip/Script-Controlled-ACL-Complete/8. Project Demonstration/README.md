# 8. Project Demonstration

## Demonstration Flow

### Step 1
Open the target ServiceNow table.

### Step 2
Show the `u_access_level` field on sample records.

### Step 3
Log in or impersonate a normal user and open:
- Public record
- Restricted record
- Confidential record

### Step 4
Repeat with a restricted user.

### Step 5
Repeat with an administrator.

### Step 6
Show the ACL script and explain how the field value controls the decision.

### Step 7
Show the test results.

## Demonstration Expected Output

| User | Public | Restricted | Confidential |
|---|---|---|---|
| Normal User | Allow | Deny | Deny |
| Restricted User | Allow | Allow | Deny |
| Admin | Allow | Allow | Allow |

## Presentation Conclusion
The demonstration proves that record access changes according to both the field value and the current user's role.
