# Demo Presentation Script

1. Introduce the problem: different records require different levels of access.
2. Explain the `u_access_level` field.
3. Show the ACL configuration.
4. Explain the three explicit access rules.
5. Demonstrate a public record with a normal user.
6. Demonstrate a restricted record with a normal user and show that access is denied.
7. Demonstrate the same restricted record with a restricted user.
8. Demonstrate a confidential record with an administrator.
9. Show the negative test for an unknown value.
10. Conclude with the deny-by-default security principle.
