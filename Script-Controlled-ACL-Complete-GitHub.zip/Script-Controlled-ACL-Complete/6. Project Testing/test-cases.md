# Test Cases

## T01 – Public Record
**User:** normal user  
**Field:** `public`  
**Expected:** Access allowed  
**Reason:** Public records are explicitly allowed.

## T02 – Restricted Record / Normal User
**User:** normal user  
**Field:** `restricted`  
**Expected:** Access denied  
**Reason:** User lacks the restricted role.

## T03 – Restricted Record / Restricted User
**User:** `x_company.restricted_user`  
**Field:** `restricted`  
**Expected:** Access allowed.

## T04 – Confidential Record / Restricted User
**User:** restricted user  
**Field:** `confidential`  
**Expected:** Access denied.

## T05 – Confidential Record / Admin
**User:** admin  
**Field:** `confidential`  
**Expected:** Access allowed.

## T06 – Unknown Field Value
**User:** normal user  
**Field:** `unknown`  
**Expected:** Access denied.
