# 6. Project Testing

## Test Execution

Testing verifies that the ACL evaluates both the field value and the current user's role.

### Positive Tests
- Public record + normal user → allowed
- Restricted record + restricted user → allowed
- Confidential record + admin → allowed

### Negative Tests
- Restricted record + normal user → denied
- Confidential record + restricted user → denied
- Unknown value + normal user → denied
- Blank value + normal user → denied

## Expected Security Behavior
Access must be denied when no explicit rule grants permission.
