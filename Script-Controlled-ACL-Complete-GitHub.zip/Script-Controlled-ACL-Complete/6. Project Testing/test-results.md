# Test Results Template

| Test ID | Expected | Actual | Status |
|---|---|---|---|
| T01 | Allow | To be recorded | Pending |
| T02 | Deny | To be recorded | Pending |
| T03 | Allow | To be recorded | Pending |
| T04 | Deny | To be recorded | Pending |
| T05 | Allow | To be recorded | Pending |
| T06 | Deny | To be recorded | Pending |

Replace the `Pending` values with actual results after executing the tests in the development instance.
