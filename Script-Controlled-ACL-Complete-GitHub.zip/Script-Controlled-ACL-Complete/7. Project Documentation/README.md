# 7. Project Documentation

## Project Title
**Script-Controlled ACL – Restrict Record Access Based on Field Value**

## Abstract
This project implements record-level access control using a scripted ACL. The access decision is based on a record's field value and the role of the current user. The approach provides server-side enforcement and follows a deny-by-default model for unexpected values.

## Objectives
1. Understand ACL-based security.
2. Implement field-value-based access control.
3. Combine field checks with user roles.
4. Test authorized and unauthorized scenarios.
5. Document the implementation.

## Conclusion
A scripted ACL can provide a clear server-side security boundary when the access rules are explicitly defined and tested. The field value determines the sensitivity level, while roles determine whether a user can access protected records.
