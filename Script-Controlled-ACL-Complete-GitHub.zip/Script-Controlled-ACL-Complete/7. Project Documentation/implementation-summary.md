# Implementation Summary

### Rule 1
`public` → allow read access.

### Rule 2
`restricted` → allow users with `x_company.restricted_user` or `x_company.admin`.

### Rule 3
`confidential` → allow only `x_company.admin`.

### Rule 4
Anything else → deny.

## Maintenance
If a new access level is introduced, add an explicit rule and corresponding test cases. Do not silently allow new values.
