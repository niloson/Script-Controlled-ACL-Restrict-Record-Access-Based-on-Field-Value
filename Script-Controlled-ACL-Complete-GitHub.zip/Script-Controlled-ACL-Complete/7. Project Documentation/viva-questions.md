# Viva Questions and Answers

### 1. What is an ACL?
An Access Control List defines whether a user is permitted to perform an operation on a resource or record.

### 2. Why use a scripted ACL?
A script allows access decisions to depend on record data and runtime user information.

### 3. Why is server-side ACL important?
Server-side controls enforce security even when users bypass or manipulate client-side interfaces.

### 4. What is deny-by-default?
Only explicitly permitted conditions receive access; unexpected conditions are denied.

### 5. What does `gs.hasRole()` check?
It checks whether the current user has the specified role.

### 6. What happens for an unknown field value?
The sample implementation returns `false`, so access is denied.

### 7. Can the same design be used for write access?
Yes, but a separate ACL operation/rule should be designed and tested for write behavior.
