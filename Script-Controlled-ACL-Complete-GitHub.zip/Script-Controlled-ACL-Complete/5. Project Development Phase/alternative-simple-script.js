// Compact version for an Advanced ACL script.

var level = current.getValue('u_access_level');

if (level == 'public') {
    answer = true;
} else if (level == 'restricted') {
    answer = gs.hasRole('x_company.restricted_user') ||
             gs.hasRole('x_company.admin');
} else if (level == 'confidential') {
    answer = gs.hasRole('x_company.admin');
} else {
    answer = false;
}
