# 5. Project Development Phase

## ACL Configuration

### ACL Type
- Operation: `read`
- Type: Record
- Target: `x_company_project`
- Condition: optional basic condition
- Advanced: enabled

## Script

See `acl-script.js`.

The script uses explicit allow rules and returns `false` for all unrecognized values.

## Important
Do not rely on a client-side UI policy, client script, or hidden form field as the security boundary. The ACL must enforce access on the server.
