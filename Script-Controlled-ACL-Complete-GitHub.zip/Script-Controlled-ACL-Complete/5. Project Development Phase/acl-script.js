/*
 * Script-Controlled ACL
 * Operation: read
 * Target example: x_company_project
 *
 * Assumption:
 * current.u_access_level contains:
 *   public
 *   restricted
 *   confidential
 */

(function () {
    var accessLevel = current.getValue('u_access_level');

    // Public records are readable by authenticated users.
    if (accessLevel === 'public') {
        return true;
    }

    // Restricted records require the restricted_user role.
    if (accessLevel === 'restricted') {
        return gs.hasRole('x_company.restricted_user') ||
               gs.hasRole('x_company.admin');
    }

    // Confidential records require the admin role.
    if (accessLevel === 'confidential') {
        return gs.hasRole('x_company.admin');
    }

    // Deny unknown, empty, or unexpected values.
    return false;
})();
