# Test Plan

| Test ID | User | Record Value | Expected |
|---|---|---|---|
| T01 | Normal user | public | Allow |
| T02 | Normal user | restricted | Deny |
| T03 | Restricted user | restricted | Allow |
| T04 | Normal user | confidential | Deny |
| T05 | Admin | confidential | Allow |
| T06 | Normal user | unknown | Deny |
| T07 | Restricted user | public | Allow |
| T08 | Admin | public | Allow |

## Acceptance Criteria
The implementation is accepted when every expected result matches the observed ACL decision and unauthorized users cannot read protected records.
