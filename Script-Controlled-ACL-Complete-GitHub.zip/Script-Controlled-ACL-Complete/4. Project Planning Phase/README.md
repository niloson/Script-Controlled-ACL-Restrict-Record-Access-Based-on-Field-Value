# 4. Project Planning Phase

## Development Plan

### Phase 1 – Environment Setup
- Create or select a ServiceNow development instance.
- Create the target application/table.
- Create the access-level field.
- Create required roles.

### Phase 2 – ACL Configuration
- Create a record-level `read` ACL.
- Select the target table.
- Add the script.
- Save and activate the ACL.

### Phase 3 – Test Data
Create records with:
- `public`
- `restricted`
- `confidential`
- blank/invalid value

### Phase 4 – User Setup
Prepare test users:
- Normal user
- Restricted user
- Administrator

### Phase 5 – Validation
Execute positive and negative access tests and record the results.

## Deliverables
- ACL configuration
- ACL script
- Test cases
- Test results
- Documentation
- Demonstration screenshots
