# ACL Decision Flow

1. Request reaches the server.
2. ServiceNow evaluates the relevant ACL.
3. Script checks the record's `u_access_level`.
4. If value is `public`, allow.
5. If value is `restricted`, check `x_company.restricted_user`.
6. If value is `confidential`, check `x_company.admin`.
7. For any other value, deny.
8. ServiceNow applies the resulting ACL decision.
