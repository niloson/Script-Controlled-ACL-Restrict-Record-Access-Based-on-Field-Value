# 3. Project Design Phase

## Architecture

```text
User
  |
  v
ServiceNow Record Request
  |
  v
ACL Evaluation
  |
  +--> Read u_access_level
  |
  +--> Check current user's roles
  |
  v
Access Decision
  |
  +---- true ----> Allow record access
  |
  +---- false ---> Deny record access
```

## ACL Design
A record-level `read` ACL is applied to the target table.

### Inputs
- `current.u_access_level`
- `gs.hasRole(...)`

### Decision
The script returns `true` only for explicitly permitted combinations.

## Design Principle
The ACL follows a deny-by-default approach. A new or unexpected field value does not receive access accidentally.

## Suggested Table
`x_company_project`

## Suggested Field
`u_access_level` (string/choice)

## Suggested Roles
- `x_company.restricted_user`
- `x_company.admin`
